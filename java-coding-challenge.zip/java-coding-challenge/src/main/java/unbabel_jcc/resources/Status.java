package unbabel_jcc.resources;

public enum Status {
	
	PROCESSING, REQUESTED, COMPLETED, ERROR;

}
